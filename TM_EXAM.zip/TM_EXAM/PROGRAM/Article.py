import pickle
from glob import glob
from nltk.stem.snowball import SnowballStemmer

stemmer = SnowballStemmer("english")

covid_words = ["covid", "covid-19", "covid19", "corona", "corona-virus", "coronavirus", "sars-cov-2", "sarscov2", "sarscov-2", "sars-cov2", "2019-ncov", "2019ncov", "ncov"]
def containsCovid(text):
    words = text.split()    # Make lowercase, then split into words
    for word in words:
        if word in covid_words:
            return True
    return False

def purgeCovidKeyword(words_original):  # Wildly inefficient, but i'm kinda done with this.
    words = []
    for word in words_original:
        if not word in covid_words:
            words.append(word)
    return words


class Date:
    def __init__(self, year, month):
        self.year = year
        self.month = month


class Article:
    def __init__(self, soup=None, covid_articles=[], non_covid_articles=[], min_year=0, saveto_folder=None, loadfrom_file=None):
        # Two ways of initializing article, either load if from premade articles or make the article anew
        if not (loadfrom_file is None):
            self.loadFromFile(loadfrom_file)
        else:
            self.contains_covid = False
            if not self.usableArticle(soup):
                return
            self.date = Date(int(soup.findAll("year")[0].getText()), int(soup.findAll("month")[0].getText()))
            if self.date.year < min_year:
                return

            self.title = soup.find("article-title").getText().lower().replace('\n', '')
            self.abstract = self.readAbstract(soup).lower().replace('\n', '')
            if (containsCovid(self.title) or containsCovid(self.abstract)):
                self.contains_covid = True
            if not self.stem():                     # Returns false if something goes wrong
                return
            if saveto_folder is None:
                self.assignSelf(covid_articles, non_covid_articles)
            else:
                self.saveToFile(saveto_folder)

    def usableArticle(self, soup):
        if soup.title is None or soup.abstract is None:
            return False
        if soup.findAll("month") == []:
            return False
        return True

    def readAbstract(self, soup):
        abstract_list = soup.abstract.findAll('p')
        abstract = ""
        for p in abstract_list:
            abstract = abstract + p.getText()
        return abstract

    def stem(self):
        self.title_tokens = self.title.split()
        self.abstract_tokens = self.abstract.split()
        self.title_tokens = list(map(stemmer.stem, self.title_tokens))
        self.abstract_tokens = list(map(stemmer.stem, self.abstract_tokens))
        if len(self.title_tokens) < 3 or len(self.abstract_tokens) < 3:     # Filter all with t/a shorter than 3 words
            return False
        return True

    def assignSelf(self, covid_articles, non_covid_articles):
        if self.contains_covid:
            covid_articles.append(self)
        else:
            non_covid_articles.append(self)

    def getAllWords(self):
        all = self.title_tokens + self.abstract_tokens
        return all

    def loadFromFile(self, file):
        with open(file, 'r', encoding="utf-8") as file:
            lines = file.readlines()
            l = lines[0].split()
            self.date = Date(int(l[0]), int(l[1]))
            self.contains_covid = bool(int(lines[1]))
            self.title = lines[2]
            self.abstract = lines[3]
            self.title_tokens = lines[4].replace('\'','').replace('[', '').replace(']','').replace(',','').split()
            self.abstract_tokens = lines[5].replace('\'', '').replace('[', '').replace(']', '').replace(',', '').split()
        file.close()
        return




    def saveToFile(self, folder):
        if self.contains_covid:
            file_name = folder + "/Covid/article_" + str(len(glob(folder+"/Covid/*"))) + ".txt"
        else:
            file_name = folder + "/Non_Covid/article_" + str(len(glob(folder+"/Non_Covid/*"))) + ".txt"
        with open(file_name, 'w', encoding="utf-8") as file:
            file.write(str(self.date.year) + " " + str(self.date.month) + "\n")
            file.write(str(int(self.contains_covid)) + "\n")
            file.write(self.title + "\n")
            file.write(self.abstract + "\n")
            file.write(str(self.title_tokens) + "\n")
            file.write(str(self.abstract_tokens) + "\n")
        file.close()
